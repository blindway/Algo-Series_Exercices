package s14;
public class SetOfStringsItr {
  // TODO - A COMPLETER
  

  // ------------------------------------------------------------
  public SetOfStringsItr (SetOfStrings theSet) {
    // TODO - A COMPLETER
  }
  // ------------------------------------------------------------
  public boolean hasMoreElements() {
    return false; // TODO - A COMPLETER
  }
  // ------------------------------------------------------------
  public String   nextElement() {
    return null; // TODO - A COMPLETER
  }
  // ------------------------------------------------------------
}