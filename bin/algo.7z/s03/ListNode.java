package s03;

class ListNode {
	int elt;
	ListNode next, prev;

	ListNode(int theElement, ListNode thePrev, ListNode theNext) {
		elt = theElement;
		next = theNext;
		prev = thePrev;
	}
}
