package TE2;

public class test2 {

}
